class String
  def hex_decode
    gsub(/[^a-f0-9]/, '').scan(/../).map{|h| h.hex}.pack('c*')
  end 

  def hex_encode
    unpack('H*').first
  end 
end

# Create a 16-byte key, 8-on 8-off
keys = [
  "ff77ff77ff77ff77".hex_decode,
  "0000000000000000".hex_decode,
  "77ff77ff77ff77ff".hex_decode,
  "0000000000000000".hex_decode,
]


data = $stdin.read.bytes

# Extend the key to create a sufficiently large pad
key = keys.join.bytes
while key.length < data.length do
  key = key + keys.join.bytes
end

# XOR the input with the contents of the pad
puts data.zip(key).map{|p,k| p^k}.pack("c*")
