# Convenience functions
class String
    def hex_decode
          gsub(/[^a-f0-9]/, '').scan(/../).map{|h| h.hex}.pack('c*')
            end
      def hex_encode
            unpack('H*').first
              end
end

# Plaintext and Ciphertext, from ciphertext.txt and blinkenlights.txt
p1 = '0909 0941 4348 5455'.hex_decode
p2 = '2d2d 2d2d 2d2d 2d2d'.hex_decode
c1 = 'f67e f636 bc3f ab22'.hex_decode
c2 = '5ad2 5ad2 5ad2 5ad2'.hex_decode

# String XOR
k1 = p1.bytes.zip(c1.bytes).map{|p, c| p ^ c}.pack('c*')
k2 = p2.bytes.zip(c2.bytes).map{|p, c| p ^ c}.pack('c*')

# Print
puts "Key 1: #{k1.hex_encode}"
puts "Key 2: #{k2.hex_encode}"
