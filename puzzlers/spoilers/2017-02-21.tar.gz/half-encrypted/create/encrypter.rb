class String
  def hex_decode
    gsub(/[^a-f0-9]/, '').scan(/../).map{|h| h.hex}.pack('c*')
  end 

  def hex_encode
    unpack('H*').first
  end 
end

keys = [
  "ff77ff77ff77ff77".hex_decode,
  "0000000000000000".hex_decode,
  "77ff77ff77ff77ff".hex_decode,
  "0000000000000000".hex_decode,
]


data = $stdin.read.bytes

key = keys.join.bytes
while key.length < data.length do
  key = key + keys.join.bytes
end

puts data.zip(key).map{|p,k| p^k}.pack("c*")
