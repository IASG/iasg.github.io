head -c 10 flag.txt | base64 | head -c -1 > flag_p1
tail -c +11 flag.txt | head -c 11 | base64 | head -c -1 > flag_p2
tail -c +22 flag.txt > flag_p3

ruby xor_p3.rb

xxd -p flag_p1 | head -c -1 > part1
xxd -p flag_p2 | head -c -1 > part2
xxd -p flag_p3_final > part3

cat part1 part2 part3 > puzzler
