require 'base64'

# Read in hex
hex = IO.read('puzzler')
puts "Hex: #{hex}"

# Convert from hex to byte array
puzzler = hex.scan(/../).map{|c| c.hex}
puts "Bytes (#{puzzler.size}) #{puzzler}"

# Split into 16-byte chunks (three parts)
p1 = puzzler[0..15]
p2 = puzzler[16..31]
p3 = puzzler[32..47]

# First two parts just un-base64
plain1 = Base64.decode64(p1.pack('C*'))
plain2 = Base64.decode64(p2.pack('C*'))

# Third is XOR of all three parts
plain3 = p3.zip(p1, p2).map{|b1, b2, b3| b1 ^ b2 ^ b3}.pack('C*')

puts "#{plain1}#{plain2}#{plain3}"
