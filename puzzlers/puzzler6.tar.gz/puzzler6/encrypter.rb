#! /usr/bin/env ruby

ptext = ARGF.read

key = Time.now.to_i & 0xffffffff

pad = ""
while pad.length < ptext.length do
  pad = pad + [(key >> 24),
               ((key >> 16) & 0xff),
               ((key >> 8) & 0xff), 
               (key & 0xff)].pack('c*')
  key = (key * 467) % 0x100000000
end

puts ptext.bytes.zip(pad.bytes).map{|p,k| p^k}.pack('c*')
